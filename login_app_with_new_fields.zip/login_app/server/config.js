export default {
    JWT_SECRET : "J/R57Y85l6bWf9ceusgQ0xo4h5P2arA0TdIj3n4H4yQ=",
    EMAIL: "mortimer.adams@ethereal.email",
    PASSWORD: "4QhbyjtDZkfWqGtFPe",
   // ATLAS_URI: "mongodb+srv://admin:admin123@cluster0.n9yw8so.mongodb.net/?retryWrites=true&w=majority"
}